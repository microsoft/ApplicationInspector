﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RulesEngine
{
    [Flags]
    public enum Confidence { Low = 1, Medium = 2, High = 4 }
}
